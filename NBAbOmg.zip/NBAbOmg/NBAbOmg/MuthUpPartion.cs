﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NBAbOmg
{
    public partial class Matchup
    {
        public string statusString
        {
            get
            {
                string res = null;
                if (Status == 1)
                {
                    res = "Finished";
                }
                if (Status == 0)
                {
                    res = "Running";
                }
                if (Status == -1)
                {
                    res = "Not start";
                }
                return (res);
            }
        }
        public string statusColor
        {
            get
            {
                string res = null;
                if (Status == 1)
                {
                    res = "Gray";
                }
                if (Status == 0)
                {
                    res = "Red";
                }
                if (Status == -1)
                {
                    res = "Blue";
                }
                return (res);
            }
        }
        public string statusButton
        {
            get
            {
                string res = "false";
                if (Status == 1)
                {
                    res = "true";
                }
                return res;
            }
        }
    }
}
