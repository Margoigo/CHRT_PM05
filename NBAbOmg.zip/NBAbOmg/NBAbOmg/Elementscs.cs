﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace NBAbOmg
{
    /// <summary>
    /// класс для работы с окнами приложения
    /// </summary>
    public static class Elementscs
    {
       public static Frame mainframe;
        public static MainWindow main;
        
    }
}
