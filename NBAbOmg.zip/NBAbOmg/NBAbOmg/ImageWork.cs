﻿using System.IO;
using System.Windows.Media.Imaging;

namespace NBAbOmg
{
    /// <summary>
    /// Класс для работы с изображениями
    /// </summary>
    public static class ImageWork
    {
        /// <summary>
        /// Метод принимающий изображение и возвращающий массив байтов этого изображения
        /// </summary>
        /// <param name="imageC"> изображение</param>
        /// <returns> массив байтов</returns>
        public static byte[] ToByteArray(BitmapSource imageC)
        {
            MemoryStream memory = new MemoryStream();
            JpegBitmapEncoder encoder = new JpegBitmapEncoder();
            encoder.Frames.Add(BitmapFrame.Create(imageC));
            encoder.Save(memory);
            return memory.ToArray();
        }

        /// <summary>
        /// Метод принимающий  массив байтов и возвращающий изображение
        /// </summary>
        /// <param name="bytes">массив байтов</param>
        /// <returns>изображение</returns>
        public static BitmapSource ToBitmapImage(byte[] bytes)
        {
            using (var memory = new MemoryStream(bytes))
            {
                var decoder = BitmapDecoder.Create(memory, BitmapCreateOptions.None, BitmapCacheOption.OnLoad);
                return decoder.Frames[0];
            }
        }
    }
}
