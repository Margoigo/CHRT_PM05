﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace NBAbOmg.Pages
{
    /// <summary>
    /// Логика взаимодействия для PagePlayersMain.xaml
    /// </summary>
    public partial class PagePlayersMain : Page
    {
        NBAEntities NBAEntities;
        List<PlayerInTeam> currentplayrslist;
        int counter = 10;
        int taker = 0;
        int mnog;
        Button colorButton;


        public PagePlayersMain()
        {
            InitializeComponent();
            NBAEntities = new NBAEntities();
            mnog = NBAEntities.PlayerInTeam.ToList().Count();
            currentplayrslist = NBAEntities.PlayerInTeam.ToList().Take(counter).ToList();
            playerInTeamDataGrid.ItemsSource = currentplayrslist;
            cmbSeason.ItemsSource = NBAEntities.Season.ToList();
            cmbTeams.ItemsSource = NBAEntities.Team.ToList();
            cmbPlayers.ItemsSource = NBAEntities.Player.ToList();
            lbMax.Content += (Math.Truncate((decimal)(mnog / 10))).ToString();
            txtCounter.Text = "1";
            foreach (UIElement c in stackPaneldMain.Children)
            {
                if (c is Button)
                {
                    ((Button)c).Click += Button_Click;
                }
            }
        }
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if (colorButton != null)
            {
                colorButton.Background = Brushes.Transparent;
            }
            colorButton = (Button)e.OriginalSource;
            ((Button)e.OriginalSource).Background = Brushes.Lavender;
            string ss = (((Button)e.OriginalSource).Content).ToString();
            if (ss == "ALL")
            {
                currentplayrslist = NBAEntities.PlayerInTeam.ToList();
                playerInTeamDataGrid.ItemsSource = currentplayrslist;
                return;
            }

            currentplayrslist = NBAEntities.PlayerInTeam.ToList();
            currentplayrslist = currentplayrslist.Where(x => x.Player.Name[0] == ss[0]).ToList();
            playerInTeamDataGrid.ItemsSource = currentplayrslist;
        }

        private void CmbSeason_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            Season season = cmbSeason.SelectedItem as Season;
            currentplayrslist = NBAEntities.PlayerInTeam.Where(x => x.SeasonId == season.SeasonId).ToList();
            playerInTeamDataGrid.ItemsSource = currentplayrslist;
        }

        private void CmbTeams_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            Team team = cmbTeams.SelectedItem as Team;
            currentplayrslist = NBAEntities.PlayerInTeam.Where(x => x.TeamId == team.TeamId).ToList();
            playerInTeamDataGrid.ItemsSource = currentplayrslist;
        }

        private void CmbPlayers_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

            Player player = cmbPlayers.SelectedItem as Player;
            currentplayrslist = NBAEntities.PlayerInTeam.Where(x => x.PlayerId == player.PlayerId).ToList();
            playerInTeamDataGrid.ItemsSource = currentplayrslist;
        }

        private void BtnLeft_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (taker <= 0)
                {
                    return;
                }
                taker -= 10;
                currentplayrslist = NBAEntities.PlayerInTeam.ToList().Skip(taker).Take(counter).ToList();
                playerInTeamDataGrid.ItemsSource = currentplayrslist;
                txtCounter.Text = ((taker + 10) / 10).ToString();

            }
            catch { };
        }

        private void BtndoubleLeft_Click(object sender, RoutedEventArgs e)
        {
            currentplayrslist = NBAEntities.PlayerInTeam.ToList().Take(counter).ToList();
            playerInTeamDataGrid.ItemsSource = currentplayrslist;
            txtCounter.Text = 1.ToString();
            taker = 0;
        }

        private void BtnRight_Click(object sender, RoutedEventArgs e)
        {
            if (taker >= (Math.Truncate((decimal)(mnog / 10))))
            {
                return;
            }
            taker += 10;
            currentplayrslist = NBAEntities.PlayerInTeam.ToList().Skip(taker).Take(counter).ToList();
            playerInTeamDataGrid.ItemsSource = currentplayrslist;
            txtCounter.Text = ((taker + 10) / 10).ToString();

        }

        private void BtnDoubleRight_Click(object sender, RoutedEventArgs e)
        {
            if (taker >= (Math.Truncate((decimal)(mnog / 10))))
            {
                return;
            }
            int ss = NBAEntities.PlayerInTeam.Count();
            currentplayrslist = NBAEntities.PlayerInTeam.ToList().Skip(ss - 10).Take(counter).ToList();
            playerInTeamDataGrid.ItemsSource = currentplayrslist;
            taker = Convert.ToInt32((Math.Truncate((decimal)(mnog / 10)))) *10;
            txtCounter.Text = Convert.ToInt32((Math.Truncate((decimal)(mnog / 10)))).ToString();

        }
    }
}
