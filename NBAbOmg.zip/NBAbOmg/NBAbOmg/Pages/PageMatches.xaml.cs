﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace NBAbOmg.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageMatches.xaml
    /// </summary>
    public partial class PageMatches : Page
    {
        public List<Matchup> ListM { get; set; }
        private Matchup _matchup;

        //public event PropertyChangedEventHandler PropertyChanged;
        public Matchup curentMathup;
        //{
            //get { return _matchup; }
            //set { _matchup = value; OnPropertyChanged(); }
        //}

        private void OnPropertyChanged([CallerMemberName] string prop = "")
        {
            //PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(prop));
        }
        public PageMatches()
        {
            InitializeComponent();
            NBAEntities bAEntities = new NBAEntities();
            ListM = bAEntities.Matchup.ToList();
            DataContext = this;
        }

        private void BtnView_Click(object sender, RoutedEventArgs e)
        {
            curentMathup = (sender as Button).DataContext as Matchup;
            DataContext = null;
            DataContext = this;
        }
    }
}
